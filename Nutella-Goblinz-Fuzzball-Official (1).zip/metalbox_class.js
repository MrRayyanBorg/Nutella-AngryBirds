"use strict";
class c_metalBox extends c_crate{
  constructor(x,y,width,height){
    let options = {
			restitution: 0.99,
			friction: 0.03,
			density: 3,
			frictionAir: 0.05,
      label: "metalbox",
			collisionFilter: { //used with mouse constraints to allow/not allow iteration
				category: notinteractable,
			}
		}
    super(x,y,width,height,options)
  }
  	show() {
		const pos = this.body.position;
		const angle = this.body.angle;

		push(); //p5 translation 
			translate(pos.x, pos.y);
			rotate(angle);
      imageMode(CENTER);
      image(metalBoxImage,0,0,this.width,this.height)
		pop();
	}
}