"use strict";

//enable the matter engine
engine = Matter.Engine.create();
world = engine.world;
body = Matter.Body;

const{ 
  Engine,
  World,
  Bodies,
  Mouse,
  MouseConstraint,
  Constraint
} = Matter;

// define our categories (as bit fields, there are up to 32 available) - we will use them to allow/non allow mouse interaction
// https://brm.io/matter-js/docs/classes/MouseConstraint.html#properties
var notinteractable = 0x0001, interactable = 0x0002;
var elastic_constraint;

//screens
var rate = 60;
var menuScreen = true;
var gameoverScreen = false;

//difficulty
var easy = true;
var medium = false;
var hard = false;
var playerScore = 0;
//mouse
let mConstraint;

//sounds
let game_soundtrack;
let menu_soundtrack;
let fuzzballhitcrate;
let fuzzballhitmetal;
let levelComplete;

//game environment
var vp_width = 920, vp_height = 690;
var gameBackground;
var world, engine, body;
var ground;
var platform;
var ceiling;
var leftWall;
var rightWall;

//game objects
//wooden crates
var MAX_CRATES = 3;
var crates = [];
var crates2 = [];
var crateImage;
var crateWidth = 40;
var crateHeight = 40;

//metal boxes
var MAX_METALBOXES = 3;
var metalBoxes = [];
var metalBoxImage;
var metalBoxWidth = crateWidth*2;
var metalBoxHeight = crateHeight*2;

//fuzzball
var fuzzball, fuzzballX = 200, fuzzballY = 600, fuzzballDiameter = 50;
var fuzzballImage;
var fuzzballsLeft = 2;

//Goblin
var goblin, goblinHit;
var goblinImage;

//launcher
var launcher;

//--------------------------------------------

function preload() {
  //images
	gameBackground = loadImage('assets/SlamBackground.png')
  fuzzballImage = loadImage('assets/nutella.png')
  crateImage = loadImage('assets/Crate.png')
  metalBoxImage = loadImage('assets/metalbox.png')
  goblinImage = loadImage('assets/goblin.png')
  //sounds
  soundFormats('mp3', 'ogg');
  game_soundtrack = loadSound('assets/GameSoundTrack.mp3')
  menu_soundtrack = loadSound('assets/MenuSoundTrack.mp3')
  fuzzballhitcrate = loadSound('assets/HitWood.mp3')
  fuzzballhitmetal = loadSound('assets/HitMetal.mp3')
  goblinHit = loadSound('assets/GoblinHit.mp3')
  levelComplete = loadSound('assets/levelSound')
}

function setup() {
	//this p5 defined function runs automatically once the preload function is done
	var viewport = createCanvas(vp_width, vp_height); //set the viewport (canvas) size
	viewport.parent("viewport_container"); //move the canvas so it’s inside the target div
  create_objects();
  frameRate(rate)
  //enable the 'matter' mouse controller and attach it to the viewport object using P5s elt property
	let vp_mouse = Matter.Mouse.create(viewport.elt); //the 'elt' is essentially a pointer the the underlying HTML element#
  vp_mouse.pixelRatio = pixelDensity(); //update the pixel ratio with the p5 density value; this supports retina screens, etc
  let options = {
		mouse: vp_mouse,
		collisionFilter: {
			mask: interactable //specify the collision catagory (multiples can be OR'd using '|' )
		}
	}
  elastic_constraint = Matter.MouseConstraint.create(engine, options); //see docs on https://brm.io/matter-js/docs/classes/Constraint.html#properties
	Matter.World.add(world, elastic_constraint); //add the elastic constraint object to the world
  Matter.Events.on(engine, 'collisionEnd', collisions);
  score(0)
}

function draw() {
	//this p5 defined function runs every refresh cycle
  Matter.Engine.update(engine);
  paint_background();
  paint_assets();

  if(elastic_constraint.body !== null) {
		let pos = elastic_constraint.body.position; //create an shortcut alias to the position (makes a short statement)	
		let mouse = elastic_constraint.mouse.position;
		stroke("#00ff00");
		line(pos.x, pos.y, mouse.x, mouse.y);
	}
  
}

//--------------------------------------------
//objects
function create_objects(){
  //create ground, walls, and ceiling
  ground = new c_ground(vp_width/2, vp_height+30, vp_width, 100);
  platform = new c_ground(vp_width-200, vp_height-150, 250, 15);
  ceiling = new c_ground(vp_width/2, -50, vp_width, 100);
  leftWall = new c_ground(-100, vp_height/2, 200, vp_width-50);
  rightWall = new c_ground(vp_width+100, vp_height/2, 200, vp_width-50);
  
  boxStructures();
  createFuzzball();
  createlauncher();
}

function createFuzzball(){
  //create fuzzball
  fuzzball = new c_fuzzball(fuzzballX, fuzzballY, fuzzballDiameter);
}

function createlauncher(){
  //create fuzzball
  launcher = new c_launcher(fuzzballX, fuzzballY-100, fuzzball.body);
}

function collisions(event) {
	//runs as part of the matter engine after the engine update, provides access to a list of all pairs that have ended collision in the current frame (if any)
  //console.log(event.pairs[0].collision)
	event.pairs.forEach((collide) => { //event.pairs[0].bodyA.label
		//console.log(collide.bodyA.label + " - " + collide.bodyB.label);

		if( 
			(collide.bodyA.label == "fuzzball" && collide.bodyB.label == "crate") ||
			(collide.bodyA.label == "crate" && collide.bodyB.label == "fuzzball")
		) {
		  fuzzballhitcrate.play()
      score(50);
		  console.log("Fuzzball <> Wooden Crate Collision");
		}
    else if( 
			(collide.bodyA.label == "fuzzball" && collide.bodyB.label == "metalbox") ||
			(collide.bodyA.label == "metalbox" && collide.bodyB.label == "fuzzball")
		){
      fuzzballhitmetal.play();
      score(25);
      console.log("Fuzzball <> Metal box Collision");
    }
    else if( 
			(collide.bodyA.label == "fuzzball" && collide.bodyB.label == "goblin") ||
			(collide.bodyA.label == "goblin" && collide.bodyB.label == "fuzzball")
		){
      goblinHit.play();
      score(300);
      console.log("Fuzzball <> Goblin Collision");
    }
	});
}

function apply_velocity() {
  //apply velocity to fuzzball
	Matter.Body.setVelocity( fuzzball.body, {x: 10, y: -5});
};

function apply_angularvelocity() {
  //apply angular velocity to crates
  for(var i=0;i<MAX_CRATES;i++){

	  Matter.Body.setAngularVelocity( crates[i].body, Math.PI/6);
  }

  for(var i=0;i<MAX_CRATES;i++){

	  Matter.Body.setAngularVelocity(crates2[i].body, Math.PI/6);
  }

  for(var i=0;i<MAX_METALBOXES;i++){

	  Matter.Body.setAngularVelocity( metalBoxes[i].body, Math.PI/6);
  }
};

function apply_force() {
  //apply force to crates
  for(var i=0;i<MAX_CRATES;i++){
    Matter.Body.applyForce( crates[i].body, {
      x: crates[i].body.position.x, 
      y: crates[i].body.position.y
    }, {
      x: 0.05, 
      y: -50.5
    });
  };
  for(var i=0;i<MAX_CRATES;i++){
    Matter.Body.applyForce( crates2[i].body, {
      x: crates2[i].body.position.x, 
      y: crates2[i].body.position.y
    }, {
      x: 0.05, 
      y: -50.5
    });
  };
  for(var i=0;i<MAX_METALBOXES;i++){

    Matter.Body.applyForce( metalBoxes[i].body, {
      x: metalBoxes[i].body.position.x, 
      y: metalBoxes[i].body.position.y
    }, {
      x: 0.05, 
      y: -50.5
    });
  };
};

function get_random(min, max) {
	min = Math.ceil(min);
	max = Math.floor(max);
	return Math.floor(Math.random() * (max - min) + min); //The maximum is exclusive and the minimum is inclusive
}

function paint_background() {
	//access the game object for the world, use this as a background image for the game
	background(gameBackground); 
}

function paint_assets() {
  //show environment
	// ground.show();
  //ceiling.show();
  // leftWall.show();
  // rightWall.show();
  platform.show();
  
  //show objects
  for(var i=0;i<MAX_CRATES;i++){
	  crates[i].show();
    crates2[i].show()
  }
  
  for(var i=0;i<MAX_METALBOXES;i++){
	  metalBoxes[i].show();
  }
  launcher.show();
	fuzzball.show();
  goblin.show();
  //screens
  showMenu();
}

//screens
function mouseClicked(){
  if(menuScreen ===true){
    restartGame();
    menuScreen = false;
    game_soundtrack.setVolume(0.5);
    game_soundtrack.play();
  }
  if(gameoverScreen===true){
    gameoverScreen = false;
    menuScreen = true;
  }
  if(menu_soundtrack.isPlaying()===true){
    menu_soundtrack.stop();
  }
}

function showMenu(){
  if (menuScreen === true){
    fill(0);
    rect(vp_width/2,vp_height/2,vp_width,vp_height)
    fill(0, 255, 0)
    stroke(0);
    strokeWeight(0.3)
    textSize(65) && textAlign(CENTER)
    text('Fuzzball', (vp_width / 2), vp_height / 3);
    textSize(20) && textStyle(NORMAL)
    text('click anywhere to play', (vp_width / 2), vp_height / 2);
    text('Nutella Goblins', (vp_width / 2), vp_height / 5);
    if(menu_soundtrack.isPlaying()===false){
      menu_soundtrack.setVolume(0.5);
      menu_soundtrack.play();
    }if(levelComplete.isPlaying()===true){
      levelComplete.stop()
    }
  }
  if(gameoverScreen === true){
    fill(0);
    rect(vp_width/2,vp_height/2,vp_width,vp_height)
    fill(0, 255, 0)
    stroke(0);
    strokeWeight(0.3)
    textSize(65) && textAlign(CENTER)
    text('Your Score: ' + playerScore, (vp_width / 2), vp_height / 3);
    textSize(20) && textStyle(NORMAL)
    text('click to return to main menu', (vp_width / 2), vp_height / 2);
    text('Level Completed', (vp_width / 2), vp_height / 5);
    if(game_soundtrack.isPlaying()===true){
      game_soundtrack.stop()
    }if(levelComplete.isPlaying()===false){
      levelComplete.play()
    }
  }
}

function mouseReleased() {
  if (menuScreen ===false){
    setTimeout(() => {launcher.release();}, 40);
    fuzzball.setNotInteractable()
  }
}

function countFuzzballs(){
  if (fuzzballsLeft > 0 ){
    fuzzballsLeft -= 1;
  }
}

function score(points) {
	let effectspeed = 60;
	let animatespeed = 500;

	$("#scoreboard").finish();
  if (points>0){
        document.getElementById('points').innerHTML = "+" + points;
    $('#scoreboard').removeAttr('style'); //remove any applied styles
    $("#scoreboard").fadeIn(effectspeed, function () {
      $("#scoreboard").animate({
        top: '+=50px',
        opacity: 0
      }, animatespeed);
    });
  }
  document.getElementById('fuzzballCounter').innerHTML = "Nutellas Left: " + fuzzballsLeft;

	playerScore += points;
	document.getElementById('status').innerHTML = "Score: " + playerScore;
}

function keyPressed(){
  //esc
  if(keyCode===27){
    restartGame();
    menuScreen=true;
    gameoverScreen = false;
  }
  //enter
  if (keyCode === 13 && fuzzballsLeft != 0){
    resetFuzzball();
  }else if(keyCode === 13 && fuzzballsLeft == 0 && menuScreen === false){
    gameoverScreen = true;
  }
}

function restartGame(){
  fuzzballsLeft = 2;
  playerScore = 0;
  score(0);
  fuzzball.remove();
  for(let i=0;i<MAX_CRATES;i++){
    crates[i].remove()
    crates2[i].remove()
  }
  for(let i=0;i<MAX_METALBOXES;i++){
    metalBoxes[i].remove()
  }
  goblin.remove();
  create_objects();
	launcher.attach(fuzzball.body);
  game_soundtrack.stop();
}

function resetFuzzball(){
  fuzzball.remove();
  createFuzzball();
	launcher.attach(fuzzball.body);
  fuzzball.setInteractable();
  countFuzzballs();
  score(0);
}

function boxStructures(){
  //Create easy structure
  //create metal boxes
  
  for(let i=0;i<MAX_METALBOXES;i++){
    metalBoxes[i] = new c_metalBox(vp_width-(120+i*metalBoxWidth), vp_height-160, metalBoxWidth, metalBoxHeight);
  }
  //create crates
  for(let i=0;i<MAX_CRATES;i++){
    crates[i] = new c_crate(vp_width-120-(metalBoxWidth*2), vp_height-160-metalBoxHeight-(i*crateHeight), crateWidth, crateHeight);
    crates2[i] = new c_crate(vp_width-120, vp_height-160-metalBoxHeight-(i*crateHeight), crateWidth, crateHeight);
  }
  //create goblin
  goblin = new c_goblin( vp_width-200, vp_height-160-metalBoxWidth, 100,100);
}