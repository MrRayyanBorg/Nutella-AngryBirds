"use strict";

class c_fuzzball {
	constructor(x, y, diameter) {
		let options = {
			restitution: 0.90,
			friction: 0.5,
			density: 0.95,
			frictionAir: 0.005,
      label: "fuzzball",
			collisionFilter: { //used with mouse constraints to allow/not allow iteration
				category: interactable,
			}
		}
		this.body = Matter.Bodies.circle(x, y, diameter/2, options); 
		Matter.World.add(world, this.body);
		
		this.x = x;
		this.y = y;
		this.diameter = diameter;
	}

	body() {
		return this.body;
	}

  setNotInteractable(){
    //Matter.Body.set(this.body,"collisionFilter.category","notinteractable")
    this.body.collisionFilter.category=1
  }

  setInteractable(){
    this.body.collisionFilter.category=2
  }
  
  remove() {
		Matter.World.remove(world, this.body);
	}

	show() {
		const pos = this.body.position;
		const angle = this.body.angle;

		
		push(); //p5 translation 
			translate(pos.x, pos.y);
			rotate(angle);
      imageMode(CENTER);
      fuzzballImage.resize(50, 75);
      image(fuzzballImage,0,0,this.diameter)
		pop();
	}
}