"use strict";

class c_ground {
	constructor(x, y, width, height, label) {
		let options = {
			isStatic: true,
			restitution: 0.99,
			friction: 0.20,
			density: 0.99,
      label: label,
			collisionFilter: { //used with mouse constraints to allow/not allow iteration
				category: notinteractable,
			}
		}
		this.body = Matter.Bodies.rectangle(x, y, width, height, options);
		Matter.World.add(world, this.body);
		
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
	}

	body() {
		return this.body;
	}

	show() {
		const pos = this.body.position;
		fill(175);
    noStroke();
		rectMode(CENTER); //switch centre to be centre rather than left, top
		rect(pos.x, pos.y, this.width, this.height);
	}
}
